#include <jni.h>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <vector>
#include <stdio.h>
#include <iostream>


using namespace std;
using namespace cv;

extern "C" {
JNIEXPORT void JNICALL Java_com_example_detecttrafficsign_DetectActivity_setBlur(JNIEnv*, jobject, jlong matColor);

JNIEXPORT void JNICALL Java_com_example_detecttrafficsign_DetectActivity_setBlur(JNIEnv*, jobject, jlong matColor)
{
	//Mat& mRgb = *(Mat*)matColor;

	Mat& mImg1 = *(Mat*)matColor;
	Mat& mImg2 = *(Mat*)matColor;

	  //-- Step 1: Detect the keypoints using SURF Detector
	  int minHessian = 400;

	  OrbFeatureDetector  detector( minHessian );

	  std::vector<KeyPoint> keypoints_1, keypoints_2;

	  detector.detect( mImg1, keypoints_1 );
	  detector.detect( mImg2, keypoints_2 );

	  //-- Step 2: Calculate descriptors (feature vectors)
	  OrbDescriptorExtractor  extractor;

	  Mat descriptors_1, descriptors_2;

	  extractor.compute( mImg1, keypoints_1, descriptors_1 );
	  extractor.compute( mImg2, keypoints_2, descriptors_2 );

	  //-- Step 3: Matching descriptor vectors using FLANN matcher
	  FlannBasedMatcher matcher;
	  std::vector< DMatch > matches;
	  matcher.match( descriptors_1, descriptors_2, matches );

	  double max_dist = 0; double min_dist = 100;

	  //-- Quick calculation of max and min distances between keypoints
	  for( int i = 0; i < descriptors_1.rows; i++ )
	  { double dist = matches[i].distance;
	    if( dist < min_dist ) min_dist = dist;
	    if( dist > max_dist ) max_dist = dist;
	  }

	  printf("-- Max dist : %f \n", max_dist );
	  printf("-- Min dist : %f \n", min_dist );

	  //-- Draw only "good" matches (i.e. whose distance is less than 2*min_dist,
	  //-- or a small arbitary value ( 0.02 ) in the event that min_dist is very
	  //-- small)
	  //-- PS.- radiusMatch can also be used here.
	  std::vector< DMatch > good_matches;

	  for( int i = 0; i < descriptors_1.rows; i++ )
	  { if( matches[i].distance <= max(2*min_dist, 0.02) )
	    { good_matches.push_back( matches[i]); }
	  }

	  //-- Draw only "good" matches
	  Mat img_matches;
	  drawMatches( mImg1, keypoints_1, mImg2, keypoints_2,
	               good_matches, img_matches, Scalar::all(-1), Scalar::all(-1),
	               vector<char>(), DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS );

	  //-- Show detected matches
	  imshow( "Good Matches", img_matches );

	  for( int i = 0; i < (int)good_matches.size(); i++ )
	  { printf( "-- Good Match [%d] Keypoint 1: %d  -- Keypoint 2: %d  \n", i, good_matches[i].queryIdx, good_matches[i].trainIdx ); }
	//GaussianBlur( mRgb, mRgb, Size( 5, 5 ), 100 );
   /* Mat& mGr  = *(Mat*)addrGray;
    Mat& mRgb = *(Mat*)addrRgba;

    /// Reduce the noise so we avoid false circle detection
     // GaussianBlur( mGr, mRgb, Size(9, 9), 2, 2 );

      vector<Vec3f> circles;

      /// Apply the Hough Transform to find the circles
      HoughCircles( mGr, circles, CV_HOUGH_GRADIENT, 1, mGr.rows/8, 200, 100, 0, 0 );

      /// Draw the circles detected
        for( size_t i = 0; i < circles.size(); i++ )
        {
            Point center(cvRound(circles[i][0]), cvRound(circles[i][1]));
            int radius = cvRound(circles[i][2]);
            // circle center
            circle( mRgb, center, 3, Scalar(0,255,0), -1, 8, 0 );
            // circle outline
            circle( mRgb, center, radius, Scalar(0,0,255), 3, 8, 0 );
         }*/
}



}
