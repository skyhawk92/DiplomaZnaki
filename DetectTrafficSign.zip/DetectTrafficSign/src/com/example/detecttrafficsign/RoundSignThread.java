package com.example.detecttrafficsign;

import java.util.ArrayList;
import java.util.List;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfInt4;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.core.RotatedRect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

import android.provider.ContactsContract.CommonDataKinds.Photo;

import com.example.detecttrafficsign.DetectedObject;

class RoundSignThread extends Thread{
	
	public Mat source, colorImage;
	public List<DetectedObject> detectedObjects;
	public boolean finished = false;
	
	int minEllipseSize = 80;
	int maxEllipseSize = 200;
	
	int h = 0;
	int s = 0;
	int v = 0;


	public RoundSignThread(){
		super();
	}
	
	public RoundSignThread(Mat source, Mat colorImage, List<DetectedObject> detectedObjects, int h, int s, int v){
		super();
		this.source = source;
		this.colorImage = colorImage;
		this.detectedObjects = detectedObjects;
		this.h = h;
		this.s = s;
		this.v = v;
		System.loadLibrary("basic_jni");
	}
	
	public boolean isFinished(){
		return this.finished;
	}
	
	public Mat getSource(){
		return this.source;
	}
	
	public void run(){
		
	/*	try{
			Imgproc.cvtColor(this.source, this.source, Imgproc.COLOR_RGB2GRAY, 3);
		}
		catch(Exception e){
			System.out.println(e);
		} */
		
		setBlur(this.source.getNativeObjAddr());
		
	//	extractRed(); 
	//	Imgproc.GaussianBlur(this.source, this.source, new Size(5,5), 100);
		//Imgproc.cvtColor(this.source, this.source, Imgproc.COLOR_RGB2GRAY);

	//	this.findEllipses(this.source);
	  	this.finished = true;
	}
	
	private void findEllipses(Mat input){
		Mat thresholdOutput = new Mat();
	  	int thresh = 150;

	  	List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
	  	MatOfInt4 hierarchy = new MatOfInt4();

	  	//Imgproc.threshold(source, thresholdOutput, thresh, 255, Imgproc.THRESH_BINARY);
	  	Imgproc.Canny(source, thresholdOutput, 50, 180);
	  	Imgproc.findContours(thresholdOutput, contours, hierarchy, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
	  	source = thresholdOutput;
	  	RotatedRect minEllipse[] = new RotatedRect[contours.size()];
	  	
	  	for(int i=0; i<contours.size();i++){
	  		MatOfPoint2f temp=new MatOfPoint2f(contours.get(i).toArray());

	  		if(temp.size().height > minEllipseSize && temp.size().height < maxEllipseSize){
	  			double a = Imgproc.fitEllipse(temp).size.height;
	  			double b = Imgproc.fitEllipse(temp).size.width;
	  			if(Math.abs(a - b) < 10)
	  				minEllipse[i] = Imgproc.fitEllipse(temp);
	  		}
	  	}
	  	
	  	detectedObjects.clear();
	//  	System.gc();
	  	for( int i = 0; i< contours.size(); i++ ){
	  		Scalar color = new Scalar(180, 255, 180);
	  		if(minEllipse[i] != null){
	  			detectedObjects.add(new DetectedObject(minEllipse[i].center));
	  			DetectedObject detectedObj = new DetectedObject(minEllipse[i].center);
	  			//double val = detectedObj.compareMat(source);
	  		/*	if(detectedObj.isSign(source)){
	  				Core.ellipse(source, minEllipse[i], color, 2, 8);
	      		}*/
	  			Core.ellipse(source, minEllipse[i], color, 2, 8);
	  		//	Point p1 = new Point(minEllipse[i].center.x-10, minEllipse[i].center.y-10);
	  		//	Point p2 = new Point(minEllipse[i].center.x+10, minEllipse[i].center.y+10);
	  		//	Core.rectangle(source, p1, p2, color, 2);
	  		}
	  	}
	}
	

	private void findCircles(){
		int iCannyUpperThreshold = 100;
		int iMinRadius = 20;
		int iMaxRadius = 400;
		int iAccumulator = 300;
		
		Mat circles = new Mat();
		
		Imgproc.HoughCircles(source, source, Imgproc.CV_HOUGH_GRADIENT, 
		         2.0, source.rows() / 8, iCannyUpperThreshold, iAccumulator, 
		         iMinRadius, iMaxRadius);

		if (source.cols() > 0)
		    for (int x = 0; x < source.cols(); x++) 
		        {
		        double vCircle[] = source.get(0,x);

		        if (vCircle == null)
		            break;

		        Point pt = new Point(Math.round(vCircle[0]), Math.round(vCircle[1]));
		        int radius = (int)Math.round(vCircle[2]);

		        // draw the found circle
		        Core.circle(source, pt, radius, new Scalar(0,255,0), 3);
		        Core.circle(source, pt, 3, new Scalar(0,0,255), 3);
		        }
	}

	private void findRectangles(){
		Mat thresholdOutput = new Mat();
	  	int thresh = 150;
	  	
	  	//MatOfPoint contours;
	  	List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
	  	MatOfInt4 hierarchy = new MatOfInt4();
	  	
	  	Imgproc.threshold(source, thresholdOutput, thresh, 255, Imgproc.THRESH_BINARY);
	  	Imgproc.findContours(thresholdOutput, contours, hierarchy, Imgproc.RETR_TREE, Imgproc.CHAIN_APPROX_SIMPLE, new Point(0, 0));
	  
	  	RotatedRect minRect[] = new RotatedRect[contours.size()];
	  	
	  	for( int i = 0; i< contours.size(); i++ ){
	  		MatOfPoint2f temp=new MatOfPoint2f(contours.get(i).toArray());
	  		if(temp.size().height > 80)
	  			minRect[i] = Imgproc.minAreaRect(temp);
	  	}
	  	detectedObjects.clear();
	  	
	  	for( int i = 0; i< contours.size(); i++ ){
	  		Scalar color = new Scalar(180, 255, 180);
	  		if(minRect[i] != null){
	  		//	Core.ellipse(source, minEllipse[i], color, 2, 8);
	  			detectedObjects.add(new DetectedObject(minRect[i].center));
	  			DetectedObject detectedObj = new DetectedObject(minRect[i].center);
	  			Point rectPoints[] = new Point[4];
	  			minRect[i].points(rectPoints);
	  			for( int j = 0; j < 4; j++ ){
	  				Core.line( source, rectPoints[j], rectPoints[(j+1)%4], color, 1);
	  			}
	  		}
	  	}
	  	
	}

	private void extractRed(){
	//	Imgproc.GaussianBlur(this.source, this.source, new Size(5,5), 100);
	//	Core.inRange(hsv, new Scalar(0,0,0), new Scalar(20,255,255), this.source);
//		Core.inRange(this.source, new Scalar(this.h,this.s,this.v), new Scalar(190,190,190), this.source);
	//	Core.inRange(this.source, new Scalar(165,15,15), new Scalar(255,255,255), this.source);
		//Imgproc.GaussianBlur(hsv, this.source, new Size(5,5), 50);
		//Imgproc.blur(hsv, this.source, new Size(5,5));
	//	Imgproc.threshold(hsv, this.source, 150, 255, Imgproc.THRESH_BINARY);
	//	Imgproc.Canny(hsv, this.source, 20, 150, 3, true);
		Mat hsv = new Mat();
		try{
			Imgproc.cvtColor(this.source, hsv, Imgproc.COLOR_RGB2HSV);
		}
		catch(Exception e){
			System.out.println(e);
		} 
		
		List<Mat> channels = new ArrayList<Mat>();
		Core.split(hsv, channels);
		
		// opencv = hue values are divided by 2 to fit 8 bit range
	    float red1 = 25/2.0f;
	    // red has one part at the beginning and one part at the end of the range (I assume 0� to 25� and 335� to 360�)
	    float red2 = (360-25)/2.0f;
	    
	    Mat thresh1 = channels.get(0);
	    Mat thresh2 = channels.get(0);
	    

	    
	 /*   for(int i=0;i<thresh1.rows();i++){
	    	for(int j=0;j<thresh1.cols();j++){
	    		double pixel[] = thresh1.get(i, j);
	    		if(pixel[0] > red2 || pixel[0] < red1){
	    			this.source.put(i, j, 0);
	    		}
	    		else{
	    			pixel[0] = 0;
	    			this.source.put(i,j,255);
	    		}
	    	}
	    }*/
	    this.source = thresh1;
	    
	}

	public native void setBlur(long matColor);
	
}