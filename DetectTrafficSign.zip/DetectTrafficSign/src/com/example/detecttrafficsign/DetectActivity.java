package com.example.detecttrafficsign;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

import org.opencv.android.BaseLoaderCallback;
import org.opencv.android.LoaderCallbackInterface;
import org.opencv.android.OpenCVLoader;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewFrame;
import org.opencv.android.CameraBridgeViewBase.CvCameraViewListener2;
import org.opencv.android.Utils;
import org.opencv.core.Core;
import org.opencv.core.CvException;
import org.opencv.core.CvType;
import org.opencv.core.Mat;




import org.opencv.core.MatOfDMatch;
import org.opencv.core.MatOfInt4;
import org.opencv.core.MatOfKeyPoint;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.RotatedRect;
import org.opencv.core.Scalar;
import org.opencv.features2d.DMatch;
import org.opencv.features2d.DescriptorExtractor;
import org.opencv.features2d.DescriptorMatcher;
import org.opencv.features2d.FeatureDetector;
import org.opencv.features2d.Features2d;
import org.opencv.highgui.Highgui;
import org.opencv.imgproc.Imgproc;

import com.example.detecttrafficsign.RoundSignThread;
import com.example.detecttrafficsign.DetectedObject;
import com.example.detecttrafficsign.R;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.hardware.Camera.Size;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SubMenu;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnTouchListener;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class DetectActivity extends Activity implements CvCameraViewListener2, OnTouchListener{

	private SeekBar sbH, sbS, sbV;
    private TextView tvH, tvS, tvV, tvMatches;
    private Switch sw1;
    private ImageView imageView1;
    private Bitmap bmp = null;
    private BitmapDrawable ob = null;
    Mat image;
	Mat imageGray;
	Bitmap bitmap = null;
	Mat frame;
	Mat original;
	org.opencv.core.Size zeroSize = new org.opencv.core.Size(0,0);
    
    int h = 0;
    int s = 0;
    int v = 0;
	int goodmatches = 0;
	int allmatches = 0;
	int maxMatches = 0;
	int currentMatches = 0;
	int signImage = 0;
	org.opencv.core.Size targetSize = new org.opencv.core.Size(150,150);
	int targetH = 0;
	int targetW = 0;
    
    private RoundSignThread cameraFrameThread;
    private YellowSignThread yellowSignThread;;
       
    public List<DetectedObject> detectedObjects = new ArrayList<DetectedObject>();
	public List<Mat> possibleSigns = new ArrayList<Mat>();
	public List<Mat> finalSigns = new ArrayList<Mat>();
    public List<Mat> folderDescriptors = new ArrayList<Mat>();
    public List<Mat> possibleSignsDescriptors = new ArrayList<Mat>();
    
	private static final String TAG = "OCVSample::Activity";

    private SignView mOpenCvCameraView;
    private List<Size> mResolutionList;
    private MenuItem[] mEffectMenuItems;
    private SubMenu mColorEffectsMenu;
    private MenuItem[] mResolutionMenuItems;
    private SubMenu mResolutionMenu;
	
    private BaseLoaderCallback mLoaderCallback = new BaseLoaderCallback(this) {
        @Override
        public void onManagerConnected(int status) {
            switch (status) {
                case LoaderCallbackInterface.SUCCESS:
                {
                    Log.i(TAG, "OpenCV loaded successfully");
                    
                 // Load native library after(!) OpenCV initialization
                    System.loadLibrary("basic_jni");
                    
                    mOpenCvCameraView.enableView();
                    mOpenCvCameraView.setOnTouchListener(DetectActivity.this);
                } break;
                default:
                {
                    super.onManagerConnected(status);
                } break;
            }
        }
    };
    
    public DetectActivity() {
        Log.i(TAG, "Instantiated new " + this.getClass());
    }
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		Log.i(TAG, "called onCreate");
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.activity_detect);

        initalizeVariables();
        initializeListeners();
        targetH = imageView1.getDrawable().getIntrinsicHeight();
        targetW = imageView1.getDrawable().getIntrinsicWidth();
        targetSize = new org.opencv.core.Size(500,500);
        BitmapDrawable drawable = (BitmapDrawable) imageView1.getDrawable();
    	bitmap = drawable.getBitmap();    	
        
        mOpenCvCameraView = (SignView) findViewById(R.id.sign_activity_java_surface_view);
        mOpenCvCameraView.setVisibility(SurfaceView.VISIBLE);
        mOpenCvCameraView.setCvCameraViewListener(this);
        
        
	}
	
	@Override
    public void onPause()
    {
        super.onPause();
        if (mOpenCvCameraView != null)
            mOpenCvCameraView.disableView();
    }

    @Override
    public void onResume()
    {
        super.onResume();
        OpenCVLoader.initAsync(OpenCVLoader.OPENCV_VERSION_2_4_3, this, mLoaderCallback);
    }
    
    public void onDestroy() {
        super.onDestroy();
        if (mOpenCvCameraView != null)
            mOpenCvCameraView.disableView();
    }
    
    public void onCameraViewStarted(int width, int height) {
    }

    public void onCameraViewStopped() {
    }

    
    public Mat onCameraFrame(CvCameraViewFrame inputFrame) {
    	Mat rgb = inputFrame.rgba();
    	//Mat frame = calculateAndDrawKeypoints(inputFrame.rgba(), inputFrame.gray());
    	frame = inputFrame.rgba();
    	original = inputFrame.rgba();
    	findEllipses();
    	for(Mat possibleSign : possibleSigns){
    	//	if(!setDescriptors(possibleSign).equals(zeroSize)){
    			possibleSignsDescriptors.add(setDescriptors(possibleSign));
    			finalSigns.add(possibleSign);
    		//}
    	}
    	setFolderDescriptors();
    	
    	maxMatches = 0;
    	signImage = 0;
    	if(goodmatches > 0)
    		goodmatches = goodmatches;
    	
    	for(Mat possibleSignDescriptor : possibleSignsDescriptors){
    		for(Mat imageDescriptor : folderDescriptors){
    			currentMatches = compareDescriptors(imageDescriptor, possibleSignDescriptor);
    			if(currentMatches > maxMatches){
    				maxMatches = currentMatches;
    				signImage = possibleSignsDescriptors.indexOf(possibleSignDescriptor);
    				bmp = Bitmap.createBitmap(finalSigns.get(signImage).cols(), finalSigns.get(signImage).rows(),Bitmap.Config.ARGB_8888);
    				Utils.matToBitmap(finalSigns.get(signImage), bmp);
    				try{
    				imageView1.setImageBitmap(bmp);
    				}
    				catch(Exception e){
    					
    				}
    				//signImage = folderDescriptors.indexOf(imageDescriptor);
    			}
    		}
    	}
    	runOnUiThread(new Runnable() {

	        public void run() {
	        	tvMatches.setText(Integer.toString(maxMatches));
	        	//tvMatches.setText(Integer.toString(goodmatches));
	        	if(finalSigns.size() > 0){
	        		try{
	        		//if(!finalSigns.get(signImage).equals(zeroSize)){
			        //	bmp = Bitmap.createBitmap(finalSigns.get(signImage).cols(), finalSigns.get(signImage).rows(),Bitmap.Config.ARGB_8888);
			        //	Utils.matToBitmap(finalSigns.get(signImage), bmp);
			  //      	imageView1.setImageBitmap(bmp);	
	        		}
	        		catch(Exception e){
	        			
	        		}
	        	//	}
	        	}	        	  	     
	        }
	    });
    	
    	possibleSignsDescriptors.clear();
    	possibleSigns.clear();
    	finalSigns.clear();
    	folderDescriptors.clear(); 
    /*	runOnUiThread(new Runnable() {

	        public void run() {
	        	tvMatches.setText(Integer.toString(goodmatches));
	        }
	    });
    	frame = calculateAndDrawKeypoints(frame, inputFrame.gray());  */
    	//Log.i("CAMERAPROPS", mOpenCvCameraView.getExposureCompensation());    	
    	
    	//frame = loadImageFromFile("D:/eclipse workspace/DetectTrafficSign/res/drawable-mdpi/s10.png");
    //	setBlur(frame.getNativeObjAddr());
    	//Imgproc.GaussianBlur(frame, frame, new org.opencv.core.Size (5,5), 100);
    /*	cameraFrameThread = new RoundSignThread(frame, frame, detectedObjects, h ,s, v);
		cameraFrameThread.start();
    	try {
    		cameraFrameThread.join();
			frame = cameraFrameThread.getSource();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}*/
    	return frame;
  /*  	if(sw1.isChecked()){
    		yellowSignThread = new YellowSignThread(frame, detectedObjects);
    		yellowSignThread.start();
    		try{
    			yellowSignThread.join();
    			frame = yellowSignThread.getSource();
    		}
    		catch(InterruptedException e){
				e.printStackTrace();
    		}
    		
    		return frame;
    	}
    	else{
    		cameraFrameThread = new RoundSignThread(frame, frame, detectedObjects, h ,s, v);
    		cameraFrameThread.start();
	    	try {
	    		cameraFrameThread.join();
				frame = cameraFrameThread.getSource();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	    	
	    	return frame;
    	} */
    }
	
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        List<String> effects = mOpenCvCameraView.getEffectList();

        if (effects == null) {
            Log.e(TAG, "Color effects are not supported by device!");
            return true;
        }

        mColorEffectsMenu = menu.addSubMenu("Color Effect");
        mEffectMenuItems = new MenuItem[effects.size()];

        int idx = 0;
        ListIterator<String> effectItr = effects.listIterator();
        while(effectItr.hasNext()) {
           String element = effectItr.next();
           mEffectMenuItems[idx] = mColorEffectsMenu.add(1, idx, Menu.NONE, element);
           idx++;
        }

        mResolutionMenu = menu.addSubMenu("Resolution");
        mResolutionList = mOpenCvCameraView.getResolutionList();
        mResolutionMenuItems = new MenuItem[mResolutionList.size()];

        ListIterator<Size> resolutionItr = mResolutionList.listIterator();
        idx = 0;
        while(resolutionItr.hasNext()) {
            Size element = resolutionItr.next();
            mResolutionMenuItems[idx] = mResolutionMenu.add(2, idx, Menu.NONE,
                    Integer.valueOf(element.width).toString() + "x" + Integer.valueOf(element.height).toString());
            idx++;
         }

        return true;
    }

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		Log.i(TAG, "called onOptionsItemSelected; selected item: " + item);
        if (item.getGroupId() == 1)
        {
            mOpenCvCameraView.setEffect((String) item.getTitle());
            Toast.makeText(this, mOpenCvCameraView.getEffect(), Toast.LENGTH_SHORT).show();
        }
        else if (item.getGroupId() == 2)
        {
            int id = item.getItemId();
            Size resolution = mResolutionList.get(id);
            mOpenCvCameraView.setResolution(resolution);
            resolution = mOpenCvCameraView.getResolution();
            String caption = Integer.valueOf(resolution.width).toString() + "x" + Integer.valueOf(resolution.height).toString();
            Toast.makeText(this, caption, Toast.LENGTH_SHORT).show();
        }

        return true;
	}

	@SuppressLint("SimpleDateFormat")
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        Log.i(TAG,"onTouch event");
     /*   SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        String currentDateandTime = sdf.format(new Date());
        String fileName = Environment.getExternalStorageDirectory().getPath() +
                               "/sample_picture_" + currentDateandTime + ".jpg";
        mOpenCvCameraView.takePicture(fileName);
        Toast.makeText(this, fileName + " saved", Toast.LENGTH_SHORT).show(); */
        return false;
    }
	
	
	//---------------------CUSTOM METHODS------------------------------
	
	private void initalizeVariables(){
    /*	tvH = (TextView)findViewById(R.id.tvH);
    	tvS = (TextView)findViewById(R.id.tvS);
    	tvV = (TextView)findViewById(R.id.tvV);*/
    	tvMatches = (TextView)findViewById(R.id.textView2);
    	
   /* 	sbH = (SeekBar)findViewById(R.id.sbH);
    	sbS = (SeekBar)findViewById(R.id.sbS);
    	sbV = (SeekBar)findViewById(R.id.sbV);
    	
    	sw1 = (Switch)findViewById(R.id.switch1);*/
    	imageView1 = (ImageView)findViewById(R.id.imageView1);
    }
    
    private void initializeListeners(){
    /*	sbH.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
    		  int progress = 0;
    		  
    		  @Override
    		  public void onProgressChanged(SeekBar seekBar, int progresValue, boolean fromUser) {
    			  progress = progresValue;
    			  h = progress;
    		  }		
    		
    		  @Override
    		  public void onStopTrackingTouch(SeekBar seekBar) {
    			  tvH.setText("Covered: " + progress + "/" + seekBar.getMax());
    		  }

	   		  @Override
	  		  public void onStartTrackingTouch(SeekBar arg0) {
	  			  // TODO Auto-generated method stub
	  			
	  		  }
    	});
    	sbS.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
  		  int progress = 0;
  		  
  		  @Override
  		  public void onProgressChanged(SeekBar seekBar, int progresValue, boolean fromUser) {
  			  progress = progresValue;
  			  s = progress;
  		  }		
  		
  		  @Override
  		  public void onStopTrackingTouch(SeekBar seekBar) {
  			  tvS.setText("Covered: " + progress + "/" + seekBar.getMax());
  		  }

	   		  @Override
	  		  public void onStartTrackingTouch(SeekBar arg0) {
	  			  // TODO Auto-generated method stub
	  			
	  		  }
    	});
    	sbV.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
  		  int progress = 0;
  		  
  		  @Override
  		  public void onProgressChanged(SeekBar seekBar, int progresValue, boolean fromUser) {
  			  progress = progresValue;
  			  v = progress;
  		  }		
  		
  		  @Override
  		  public void onStopTrackingTouch(SeekBar seekBar) {
  			  tvV.setText("Covered: " + progress + "/" + seekBar.getMax());
  		  }

	   		  @Override
	  		  public void onStartTrackingTouch(SeekBar arg0) {
	  			  // TODO Auto-generated method stub
	  			
	  		  }
    	});*/
    }

    private Mat setDescriptors(Mat image){
    	Mat imageGray = new Mat(); 
    	Imgproc.cvtColor(image, imageGray, Imgproc.COLOR_BGR2GRAY);
    	FeatureDetector detector = FeatureDetector.create(FeatureDetector.ORB);
    	MatOfKeyPoint keypoints = new MatOfKeyPoint();
    	detector.detect(imageGray, keypoints);
    	DescriptorExtractor extractor = DescriptorExtractor.create(DescriptorExtractor.ORB);
    	Mat descriptors = new Mat(imageGray.rows(), imageGray.cols(), image.type());
    	extractor.compute(imageGray, keypoints, descriptors);
    	return descriptors;
    }
    
    private void setFolderDescriptors(){
    	// Get the AssetManager
        AssetManager manager = getAssets();
    	try {
    		String[] getImages = manager.list("minimized");
    		for(String imgName : getImages){    
    			//Log.e("IMAGE NAME----->", imgName); 
    			try{
    				InputStream open = manager.open("minimized/" + imgName);
    				Bitmap bitmap = BitmapFactory.decodeStream(open);
    				Mat folderImage = new Mat();
    				Utils.bitmapToMat(bitmap, folderImage);
    				folderDescriptors.add(setDescriptors(folderImage));
    			}
    			catch(Exception e){
    				e.printStackTrace();
    			}
    		}
    		} 
    		catch (IOException e) {
    			e.printStackTrace();
    		}
    }
    
    private int compareDescriptors(Mat descriptorImage, Mat descriptorSign){
    	MatOfDMatch matches = new MatOfDMatch();
     	DescriptorMatcher matcher = DescriptorMatcher.create(DescriptorMatcher.BRUTEFORCE);
     	matcher.clear();
     	try{
     		matcher.match(descriptorImage, descriptorSign, matches);   	
     	}
     	catch(Exception e){
     		return 0;
     	}
     	List<DMatch> matchesList = matches.toList();
     	
     	//calc min/max dist
        Double max_dist = 0.0;
        Double min_dist = 100.0;
        for(int i = 0; i < descriptorImage.rows(); i++){
            Double dist = (double) matchesList.get(i).distance;
            if(dist < min_dist) min_dist = dist;
            if(dist > max_dist) max_dist = dist;
        }
        
      //filter good matches
        LinkedList<DMatch> good_matches = new LinkedList<DMatch>();
        LinkedList<DMatch> all_matches = new LinkedList<DMatch>();
        MatOfDMatch gm = new MatOfDMatch();
        
      //good match = distance > 2*min_distance ==> put them in a list
        for(int i = 0; i < descriptorImage.rows(); i++){
        	all_matches.addLast(matchesList.get(i));
            if(matchesList.get(i).distance < 2*min_dist){   //2
                good_matches.addLast(matchesList.get(i));
            }
        }
        
        goodmatches = good_matches.size();
        allmatches = all_matches.size();
        return good_matches.size();
    }
    
    private Mat calculateAndDrawKeypoints(Mat frame, Mat frameGray){
    	image = new Mat();
        imageGray = new Mat();
        Utils.bitmapToMat(bitmap, image);
    	Imgproc.cvtColor(image, imageGray, Imgproc.COLOR_BGR2GRAY);
    	
    	FeatureDetector detector = FeatureDetector.create(FeatureDetector.ORB);    	
    	MatOfKeyPoint keypoints1 = new MatOfKeyPoint();
    	MatOfKeyPoint keypoints2 = new MatOfKeyPoint();
    	
    	detector.detect(frameGray, keypoints1);
    	detector.detect(imageGray, keypoints2);   	
    	bmp = Bitmap.createBitmap(imageGray.cols(), imageGray.rows(), Bitmap.Config.ARGB_8888);
    	Utils.matToBitmap(imageGray, bmp);
    	
    	DescriptorExtractor extractor = DescriptorExtractor.create(DescriptorExtractor.ORB);
    	Mat descriptors1 = new Mat(frameGray.rows(), frameGray.cols(), frameGray.type());
    	Mat descriptors2 = new Mat(imageGray.rows(), imageGray.cols(), imageGray.type());
    	extractor.compute(frameGray, keypoints1, descriptors1);
    	extractor.compute(imageGray, keypoints2, descriptors2);
    	
    	MatOfDMatch matches = new MatOfDMatch();
     	DescriptorMatcher matcher = DescriptorMatcher.create(DescriptorMatcher.BRUTEFORCE);
     	matcher.clear();
     	matcher.match(descriptors1, descriptors2, matches);
     	List<DMatch> matchesList = matches.toList();
     	   	
        Double max_dist = 0.0;
        Double min_dist = 100.0;
        for(int i = 0; i < descriptors1.rows(); i++){
            Double dist = (double) matchesList.get(i).distance;
            if(dist < min_dist) min_dist = dist;
            if(dist > max_dist) max_dist = dist;
        }
        
        LinkedList<DMatch> good_matches = new LinkedList<DMatch>();
        MatOfDMatch gm = new MatOfDMatch();
        
        for(int i = 0; i < descriptors1.rows(); i++){
            if(matchesList.get(i).distance < 2*min_dist){
                good_matches.addLast(matchesList.get(i));
            }
        }
        goodmatches = good_matches.size();        
        gm.fromList(good_matches);           	
        Mat img_matches = new Mat();
        
        Features2d.drawMatches(
        		frameGray,
                keypoints1, 
                imageGray,
                keypoints2, 
                gm, 
                img_matches);
        frame = frameGray;
        bmp = Bitmap.createBitmap(img_matches.cols(), img_matches.rows(),Bitmap.Config.ARGB_8888);
     	Utils.matToBitmap(img_matches, bmp);
    	return frame;
    }

    private void findEllipses(){
    	Mat thresholdOutput = new Mat();
	  	List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
	  	MatOfInt4 hierarchy = new MatOfInt4();

	  	Imgproc.Canny(frame, thresholdOutput, 50, 180);
	  	Imgproc.findContours(thresholdOutput, contours, hierarchy, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
	  	RotatedRect minEllipse[] = new RotatedRect[contours.size()];
	  	
	  	for(int i=0; i<contours.size();i++){
	  		MatOfPoint2f temp=new MatOfPoint2f(contours.get(i).toArray());
	  		if(temp.size().height > 80 && temp.size().height < 200){
	  			double a = Imgproc.fitEllipse(temp).size.height;
	  			double b = Imgproc.fitEllipse(temp).size.width;
	  			if(Math.abs(a - b) < 10)
	  				minEllipse[i] = Imgproc.fitEllipse(temp);
	  		}
	  	}	  	
	  	detectedObjects.clear();
	  	
	  	for( int i = 0; i< contours.size(); i++ ){
	  		Scalar color = new Scalar(0, 0, 0);
	  		if(minEllipse[i] != null){
	  			detectedObjects.add(new DetectedObject(minEllipse[i].center));
	  			if((int)minEllipse[i].center.x-(minEllipse[i].size.width/2) > 0 && 
	  					(int)minEllipse[i].center.y-(minEllipse[i].size.height/2) > 0 && 
	  					(int)minEllipse[i].center.x+(minEllipse[i].size.width/2) < frame.cols() && 
	  					(int)minEllipse[i].center.y+(minEllipse[i].size.height/2) < frame.rows()){
	  				Rect signRect = new Rect((int)minEllipse[i].center.x-((int)minEllipse[i].size.width/2),
	  						(int)minEllipse[i].center.y-((int)minEllipse[i].size.height/2),(int)minEllipse[i].size.width,
	  						(int)minEllipse[i].size.height);
		  			Mat cropedSign = original.submat(signRect);
		  			Mat resized = new Mat();
		  			Imgproc.resize(cropedSign, resized, targetSize);
		  			possibleSigns.add(resized);
		  			Core.ellipse(frame, minEllipse[i], color, 0, 8);
	  			}
	  			//Core.ellipse(frame, minEllipse[i], color, 2, 8);
	  		}
	  	}
    }
    
    private Mat findEllipses(Mat frame){
		Mat thresholdOutput = new Mat();
	  	int thresh = 150;

	  	List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
	  	MatOfInt4 hierarchy = new MatOfInt4();

	  	//Imgproc.threshold(source, thresholdOutput, thresh, 255, Imgproc.THRESH_BINARY);
	  	Imgproc.Canny(frame, thresholdOutput, 50, 180);
	  	Imgproc.findContours(thresholdOutput, contours, hierarchy, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
	  //	frame = thresholdOutput;
	  	RotatedRect minEllipse[] = new RotatedRect[contours.size()];
	  	
	  	for(int i=0; i<contours.size();i++){
	  		MatOfPoint2f temp=new MatOfPoint2f(contours.get(i).toArray());

	  		if(temp.size().height > 80 && temp.size().height < 200){
	  			double a = Imgproc.fitEllipse(temp).size.height;
	  			double b = Imgproc.fitEllipse(temp).size.width;
	  			if(Math.abs(a - b) < 10)
	  				minEllipse[i] = Imgproc.fitEllipse(temp);
	  		}
	  	}
	  	
	  	detectedObjects.clear();
	//  	System.gc();
	  	for( int i = 0; i< contours.size(); i++ ){
	  		Scalar color = new Scalar(180, 255, 180);
	  		if(minEllipse[i] != null){
	  			detectedObjects.add(new DetectedObject(minEllipse[i].center));
	  			DetectedObject detectedObj = new DetectedObject(minEllipse[i].center);
	  			if((int)minEllipse[i].center.x-25 > 0 && (int)minEllipse[i].center.y-25 > 0 && (int)minEllipse[i].center.x+25 < frame.cols() && (int)minEllipse[i].center.y+25 < frame.rows()){
	  				Rect signRect = new Rect((int)minEllipse[i].center.x-25,(int)minEllipse[i].center.y-25,50,50);
		  			Mat cropedSign = frame.submat(signRect);
		  			bmp = Bitmap.createBitmap(cropedSign.cols(), cropedSign.rows(),Bitmap.Config.ARGB_8888);
		  	     	Utils.matToBitmap(cropedSign, bmp);
		  	     	runOnUiThread(new Runnable() {
	
		  		        public void run() {
		  		        	imageView1.setImageBitmap(bmp);		
		  		        	tvMatches.setText(Integer.toString(goodmatches));
		  		        }
		  		    });
	  			}
	  			//double val = detectedObj.compareMat(source);
	  		/*	if(detectedObj.isSign(source)){
	  				Core.ellipse(source, minEllipse[i], color, 2, 8);
	      		}*/
	  			Core.ellipse(frame, minEllipse[i], color, 2, 8);
	  		//	Point p1 = new Point(minEllipse[i].center.x-10, minEllipse[i].center.y-10);
	  		//	Point p2 = new Point(minEllipse[i].center.x+10, minEllipse[i].center.y+10);
	  		//	Core.rectangle(source, p1, p2, color, 2);
	  		}
	  	}
	  	return frame;
	}
    
    private Mat loadImageFromFile(String fileName) {

        Mat rgbLoadedImage = null;

        // this should be in BGR format according to the
        // documentation.
        Mat image = Highgui.imread(fileName);

        if (image.width() > 0) {

            rgbLoadedImage = new Mat(image.size(), image.type());

            Imgproc.cvtColor(image, rgbLoadedImage, Imgproc.COLOR_BGR2RGB);

            image.release();
            image = null;
        }

        return rgbLoadedImage;

    }
       
    
    private Mat cropSign(Mat sign, int r){
    	int size = (int) (sign.total() * sign.channels());
    	double[] temp = new double[size];
    	int x = (int)sign.rows()/2;
    	int y = (int)sign.cols()/2;
    	return sign;
    }
    
    private void extractYellowAreas(Mat src){
		//Core.inRange(src, new Scalar(20,50,50), new Scalar(30,255,255), frame);
    	Imgproc.cvtColor(src, src, Imgproc.COLOR_BGR2HSV);
    	Core.inRange(src, new Scalar(20, 100, 100), new Scalar(30, 255, 255), frame);
	}
    
    private double angle(Point pt1, Point pt2, Point pt0){
    	double result = 0;
    	double dx1 = pt1.x - pt0.x;
        double dy1 = pt1.y - pt0.y;
        double dx2 = pt2.x - pt0.x;
        double dy2 = pt2.y - pt0.y;
        result =  (dx1*dx2 + dy1*dy2)/Math.sqrt((dx1*dx1 + dy1*dy1)*(dx2*dx2 + dy2*dy2) + 1e-10);
    	return result;
    }
    
    private Vector<Point> findSquaresInImage(Mat img){
    	Vector<Point> squares = new Vector<Point>();
    	Mat pyr = new Mat(); 
    	Mat timg = new Mat(); 
    	Mat gray = new Mat();
    	Mat gray0 = new Mat(img.cols()/2, img.rows()/2, CvType.CV_8U);
    	Imgproc.pyrDown(img, pyr, gray0.size());
    	Imgproc.pyrUp(pyr, timg, img.size());
    	Vector<Point> contours = new Vector<Point>();
    	for( int c = 0; c < 3; c++ ) {

    	}
    	return squares;
    }
    
   public native void setBlur(long matColor);
}
