package com.example.detecttrafficsign;

import org.opencv.core.Point;

public class DetectedObject {

Point position;
	
	public DetectedObject(Point p){
		this.position = p;
	}
	
}
