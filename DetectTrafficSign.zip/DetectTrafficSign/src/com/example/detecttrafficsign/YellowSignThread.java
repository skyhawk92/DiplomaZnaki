package com.example.detecttrafficsign;

import java.util.ArrayList;
import java.util.List;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfInt4;
import org.opencv.core.MatOfPoint;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.core.RotatedRect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;

public class YellowSignThread extends Thread{

	private Mat source;
	private Mat editable;
	public List<DetectedObject> detectedObjects;
	
	public YellowSignThread(){
		super();
	}

	public YellowSignThread(Mat source, List<DetectedObject> detectedObjects){
		this.source = source;
		this.editable = source;
		this.detectedObjects = detectedObjects;
	}
	
	public Mat getSource(){
		return this.source;
	}
	
	public void run(){
		Imgproc.GaussianBlur(editable, editable, new Size(5,5), 100);
		try{
			//Imgproc.cvtColor(editable, editable, Imgproc.COLOR_RGB2HSV);
			Imgproc.cvtColor(editable, editable, Imgproc.COLOR_RGB2GRAY);
		}
		catch(Exception e){
			System.out.println(e);
		}
		//findRectangles();
		//extractYellowAreas();
		this.source = this.editable;
	}
	
	private void findRectangles(){
		Mat thresholdOutput = new Mat();
	  	int thresh = 150;
	  	
	  	//MatOfPoint contours;
	  	List<MatOfPoint> contours = new ArrayList<MatOfPoint>();
	  	MatOfInt4 hierarchy = new MatOfInt4();
	  	
	  	Imgproc.threshold(this.editable, thresholdOutput, thresh, 255, Imgproc.THRESH_BINARY);
	  	Imgproc.findContours(thresholdOutput, contours, hierarchy, Imgproc.RETR_TREE, Imgproc.CHAIN_APPROX_SIMPLE, new Point(0, 0));
	  
	  	RotatedRect minRect[] = new RotatedRect[contours.size()];
	  	
	  	for( int i = 0; i< contours.size(); i++ ){
	  		MatOfPoint2f temp=new MatOfPoint2f(contours.get(i).toArray());
	  		if(temp.size().height > 50 && temp.size().height < 200)
	  			minRect[i] = Imgproc.minAreaRect(temp);
	  	}
	  	detectedObjects.clear();
	  	
	  	for( int i = 0; i< contours.size(); i++ ){
	  		Scalar color = new Scalar(180, 255, 180);
	  		if(minRect[i] != null){
	  		//	Core.ellipse(source, minEllipse[i], color, 2, 8);
	  			detectedObjects.add(new DetectedObject(minRect[i].center));
	  			DetectedObject detectedObj = new DetectedObject(minRect[i].center);
	  			Point rectPoints[] = new Point[4];
	  			minRect[i].points(rectPoints);
	  			for( int j = 0; j < 4; j++ ){
	  				Core.line( this.editable, rectPoints[j], rectPoints[(j+1)%4], color, 1);
	  			}
	  		}
	  	}
	  	
	}
	
	private void extractYellowAreas(){
		Core.inRange(editable, new Scalar(20,50,50), new Scalar(30,255,255), editable);
	}
	
}
